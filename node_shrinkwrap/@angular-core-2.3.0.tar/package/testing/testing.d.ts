export declare var __core_private_testing_placeholder__: string;
