# Installation
> `npm install --save @types/stripe`

# Summary
This package contains type definitions for stripe (https://stripe.com/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/stripe

Additional Details
 * Last updated: Tue, 08 Nov 2016 14:41:16 GMT
 * File structure: Mixed
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: Stripe

# Credits
These definitions were written by Andy Hawkins <https://github.com/a904guy/,http://a904guy.com>, Eric J. Smith <https://github.com/ejsmith/>, Amrit Kahlon <https://github.com/amritk/>, Adam Cmiel <https://github.com/adamcmiel>.
