module.exports = require('./lib/Bubleify').default;
