To see `react-transform-hmr` in action, edit `js/HelloWorld.jsx`
