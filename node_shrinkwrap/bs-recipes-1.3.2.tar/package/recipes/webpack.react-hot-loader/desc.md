To see `react-hot-loader` in action, edit `js/HelloWorld.jsx`
