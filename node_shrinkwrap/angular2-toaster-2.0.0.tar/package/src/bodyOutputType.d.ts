export declare enum BodyOutputType {
    Default = 0,
    TrustedHtml = 1,
    Component = 2,
}
