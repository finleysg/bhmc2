export declare class ToasterModule {
}
