import { Provider } from '@angular/core';
export declare const INTERNAL_BROWSER_DYNAMIC_PLATFORM_PROVIDERS: Provider[];
