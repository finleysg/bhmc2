> a blockquote
    with a 4 space indented line (not code)

sep

> a blockquote

    with some code after
