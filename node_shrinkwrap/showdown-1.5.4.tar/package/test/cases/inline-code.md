
Create a new `function`.

Use the backtick in MySQL syntax ``SELECT `column` FROM whatever``.

A single backtick in a code span: `` ` ``

A backtick-delimited string in a code span: `` `foo` ``

Please don't use any `<blink>` tags.

`&#8212;` is the decimal-encoded equivalent of `&mdash;`.