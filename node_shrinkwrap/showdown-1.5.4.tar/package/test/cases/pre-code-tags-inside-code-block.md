code inception

```
<pre><code>
<div>some html code inside code html tags inside a fenced code block</div>
</code></pre>
```

