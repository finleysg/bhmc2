
This is [an example][id] reference-style link.
This is [another] [foo] reference-style link.
This is [a third][bar] reference-style link.
This is [a fourth][4] reference-style link.

  [id]: http://example.com/  "Optional Title Here"
  [foo]: http://example.com/  (Optional Title Here)
  [bar]: http://example.com/  (Optional Title Here)
  [4]: <http://example.com/>
    "Optional Title Here"