> Define a function in javascript:
>
> ```
> function MyFunc(a) {
>     var s = '`';
> }
> ```
>
>> And some nested quote
>>
>> ```html
>> <div>HTML!</div>
>> ```
