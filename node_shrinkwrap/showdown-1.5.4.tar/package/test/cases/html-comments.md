<!-- a comment -->

<!-- a comment with *bogus* __markdown__ inside -->

words <!-- a comment --> words

<!-- comment --> words

   <!-- comment -->

    <!-- comment -->
