
These should all be escaped:

\\

\`

\*

\_

\{

\}

\[

\]

\(

\)

\#

\+

\-

\.

\!