It happened in 1986\. What a great season.
