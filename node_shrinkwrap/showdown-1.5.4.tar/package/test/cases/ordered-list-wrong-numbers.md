
 8.  Red
 1.  Green
 3.  Blue