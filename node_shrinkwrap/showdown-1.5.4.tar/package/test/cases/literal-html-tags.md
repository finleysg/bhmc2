<code>some **code** yeah</code>

some <code>inline **code** block</code>

<code>some inline **code**</code> block

yo dawg <code start="true">some <code start="false">code</code> inception</code>

<div>some **div** yeah</div>