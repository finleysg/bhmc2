*single asterisks*

_single underscores_

**double asterisks**

__double underscores__

text *with italic sentence* in middle

text __with bold sentence__ in middle

text with __bold text that
spans across multiple__ lines

underscored_word

doubleunderscore__word

asterix*word

doubleasterix**word

line with_underscored word

line with__doubleunderscored word

line with*asterixed word

line with**doubleasterixed word

some line_with_inner underscores

some line__with__inner double underscores

some line*with*inner asterixs

some line**with**inner double asterixs

another line with just _one underscore

another line with just __one double underscore

another line with just *one asterix

another line with just **one double asterix

a sentence with_underscore and another_underscore

a sentence with__doubleunderscore and another__doubleunderscore

a sentence with*asterix and another*asterix

a sentence with**doubleasterix and another**doubleasterix

escaped word\_with\_underscores

escaped word\_\_with\_\_double underscores

escaped word_\_with\__single italic underscore

escaped word\*with*asterixs

escaped word\*\*with\*\*asterixs

escaped word**\*with\***bold asterixs
