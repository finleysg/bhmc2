    > this is a pseudo blockquote
    > inside a code block

foo

    > this is another bq
    inside code
