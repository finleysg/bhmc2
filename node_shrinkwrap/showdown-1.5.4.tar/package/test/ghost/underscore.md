foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo

_baz_bar_foo_

__baz_bar_foo__

___baz_bar_foo___

baz bar foo _baz_bar_foo foo bar baz_ and foo

foo\_bar\_baz foo\_bar\_baz\_bar\_foo \_foo\_bar baz\_bar\_ baz\_foo

`foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo`


    foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo


```html
foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo
```

<pre>foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo</pre>

<pre><code class="language-html">foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo</code></pre>

<pre class="lang-html"><code class="language-html">foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo</code></pre>

<script>
var strike = "foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo";
var foo_bar_baz_bar_foo = "foo_bar_";
</script>

[foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo](http://myurl.com/foo_bar_baz_bar_foo)

<a href="http://myurl.com/foo_bar_baz_bar_foo" title="foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo">foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo</a>

<img src="http://myurl.com/foo_bar_baz_bar_foo" alt="foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo">

foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo
-----

### foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo

1. foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo
2. foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo

> blockquote foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo

* foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo
* foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo

-------

http://en.wikipedia.org/wiki/Tourism_in_Germany

[an example] [wiki]

Another [example][wiki] of a link

[wiki]: http://en.wikipedia.org/wiki/Tourism_in_Germany

<p><code>foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo</code></p>

<!-- These two cases still have bad <ems> because showdown handles them incorrectly -->

<code>foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo</code>

![foo_bar_baz foo_bar_baz_bar_foo _foo_bar baz_bar_ baz_foo](http://myurl.com/foo_bar_baz_bar_foo)

http://myurl.com/foo_bar_baz_bar_foo

<http://myurl.com/foo_bar_baz_bar_foo>

_italics_.

_italics_   .
