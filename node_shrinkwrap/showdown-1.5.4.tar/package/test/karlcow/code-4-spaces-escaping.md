    10 PRINT < > &
    20 GOTO 10