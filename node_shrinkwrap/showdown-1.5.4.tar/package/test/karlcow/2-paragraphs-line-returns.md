A first paragraph.



A second paragraph after 3 CR (carriage return).