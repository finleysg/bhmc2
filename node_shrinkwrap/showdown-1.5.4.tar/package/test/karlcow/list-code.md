*   a list containing a block of code

	    10 PRINT HELLO INFINITE
	    20 GOTO 10