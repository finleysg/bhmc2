This is a first paragraph,
on multiple lines.

This is a second paragraph
which has multiple lines too.