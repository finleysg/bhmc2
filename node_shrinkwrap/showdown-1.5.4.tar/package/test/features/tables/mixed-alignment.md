| Left-Aligned  |    Center-Aligned    | Right-Aligned |
| :------------ |:--------------------:| -------------:|
| col 3 is      | some wordy paragraph |         $1600 |
| col 2 is      |       centered       |           $12 |
| zebra stripes |       are neat       |            $1 |