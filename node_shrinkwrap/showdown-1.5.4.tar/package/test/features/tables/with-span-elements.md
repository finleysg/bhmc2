| First Header  | Second Header     |
| ------------- | ----------------- |
| **bold**      | ![img](foo.jpg)   |
| _italic_      | [link](bla.html)  |
| `some code`   | [google][1]       |
| <www.foo.com> | normal            |


  [1]: www.google.com
