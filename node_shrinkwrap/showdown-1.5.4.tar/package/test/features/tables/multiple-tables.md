Table Test
============

section 1
------------

|header1    |header2    |header3|
|-----------|-----------|---------|
|Value1     |Value2     |Value3   |


section 2
-----------

|headerA    |headerB    |headerC|
|-----------|-----------|---------|
|ValueA     |ValueB     |ValueC   |
