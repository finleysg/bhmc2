function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
__export(require('./src/services'));
var services = require('./src/services');
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    services: services
};
//# sourceMappingURL=ng2-cookies.js.map