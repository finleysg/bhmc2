export * from './src/services';
import * as services from './src/services';
declare var _default: {
    services: typeof services;
};
export default _default;
