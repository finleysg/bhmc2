/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
export var /** @type {?} */ FILL_STYLE_FLAG = 'true'; // TODO (matsko): change to boolean
export var /** @type {?} */ ANY_STATE = '*';
export var /** @type {?} */ DEFAULT_STATE = '*';
export var /** @type {?} */ EMPTY_STATE = 'void';
//# sourceMappingURL=animation_constants.js.map