import { __platform_browser_private__ as r } from '@angular/platform-browser';
export var /** @type {?} */ getDOM = r.getDOM;
//# sourceMappingURL=private_import_platform-browser.js.map