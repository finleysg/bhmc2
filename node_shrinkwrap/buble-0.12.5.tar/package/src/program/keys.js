export default {
	Program: [ 'body' ],
	Literal: []
};
