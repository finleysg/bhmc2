<a name="1.0.2"></a>
## [1.0.2](https://github.com/karma-runner/karma-jasmine/compare/v1.0.1...v1.0.2) (2016-05-04)


### Bug Fixes

* **version:** argh, make 'build' a prereq for test and fix gruntfile for eslint([f2a6109](https://github.com/karma-runner/karma-jasmine/commit/f2a6109))



<a name="1.0.1"></a>
## [1.0.1](https://github.com/karma-runner/karma-jasmine/compare/v1.0.0...v1.0.1) (2016-05-04)


### Bug Fixes

* **grunt:** load 'build' grunt task and make a pre-req for releasing([1861ae0](https://github.com/karma-runner/karma-jasmine/commit/1861ae0))



<a name="1.0.0"></a>
# [1.0.0](https://github.com/karma-runner/karma-jasmine/compare/v0.3.8...v1.0.0) (2016-05-03)



<a name="0.3.8"></a>
## [0.3.8](https://github.com/karma-runner/karma-jasmine/compare/v0.3.7...v0.3.8) (2016-03-16)


### Bug Fixes

* v0.3.7 does not work in ie8 fix #105 ([d44b489](https://github.com/karma-runner/karma-jasmine/commit/d44b489)), closes [#105](https://github.com/karma-runner/karma-jasmine/issues/105)

### Features

* **adapter:** add executedExpectationsCount to result ([666c207](https://github.com/karma-runner/karma-jasmine/commit/666c207))



