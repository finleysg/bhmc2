import { Program } from '../cli';
export declare let program: Program;
