"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
__export(require('./modal-backdrop.component'));
__export(require('./modal-options.class'));
__export(require('./modal.component'));
var modal_module_1 = require('./modal.module');
exports.ModalModule = modal_module_1.ModalModule;
