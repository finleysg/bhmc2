/** Provides default values for Pagination and pager components */
export declare class PaginationConfig {
    main: any;
    pager: any;
}
