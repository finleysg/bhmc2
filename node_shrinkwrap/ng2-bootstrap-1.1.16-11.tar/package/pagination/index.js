"use strict";
var pager_component_1 = require('./pager.component');
exports.PagerComponent = pager_component_1.PagerComponent;
var pagination_component_1 = require('./pagination.component');
exports.PaginationComponent = pagination_component_1.PaginationComponent;
var pagination_module_1 = require('./pagination.module');
exports.PaginationModule = pagination_module_1.PaginationModule;
