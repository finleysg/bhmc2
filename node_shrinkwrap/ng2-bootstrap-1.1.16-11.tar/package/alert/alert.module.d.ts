import { ModuleWithProviders } from '@angular/core';
export declare class AlertModule {
    static forRoot(): ModuleWithProviders;
}
