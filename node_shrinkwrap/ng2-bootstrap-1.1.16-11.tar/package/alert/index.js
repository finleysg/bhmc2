"use strict";
var alert_component_1 = require('./alert.component');
exports.AlertComponent = alert_component_1.AlertComponent;
var alert_module_1 = require('./alert.module');
exports.AlertModule = alert_module_1.AlertModule;
var alert_config_1 = require('./alert.config');
exports.AlertConfig = alert_config_1.AlertConfig;
