import { PopoverConfig } from './popover-config';
export declare class PopoverContainerComponent {
    placement: string;
    title: string;
    constructor(config: PopoverConfig);
}
