"use strict";
var carousel_component_1 = require('./carousel.component');
exports.CarouselComponent = carousel_component_1.CarouselComponent;
var carousel_module_1 = require('./carousel.module');
exports.CarouselModule = carousel_module_1.CarouselModule;
var slide_component_1 = require('./slide.component');
exports.SlideComponent = slide_component_1.SlideComponent;
var carousel_config_1 = require('./carousel.config');
exports.CarouselConfig = carousel_config_1.CarouselConfig;
