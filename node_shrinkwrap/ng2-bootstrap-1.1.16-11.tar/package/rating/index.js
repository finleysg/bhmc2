"use strict";
var rating_component_1 = require('./rating.component');
exports.RatingComponent = rating_component_1.RatingComponent;
var rating_module_1 = require('./rating.module');
exports.RatingModule = rating_module_1.RatingModule;
