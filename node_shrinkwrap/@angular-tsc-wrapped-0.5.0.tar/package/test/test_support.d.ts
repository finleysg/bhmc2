export declare function writeTempFile(name: string, contents: string): string;
export declare function makeTempDir(): string;
