﻿// Type definitions for RxJS-BackPressure v2.3.12
// Project: http://rx.codeplex.com/
// Definitions by: Igor Oleinikov <https://github.com/Igorbek>
// Definitions: https://github.com/borisyankov/DefinitelyTyped

///<reference path="rx.d.ts" />
///<reference path="rx.backpressure-lite.d.ts" />

declare module "rx.backpressure" {
	export = Rx;
}
