  /**
   * Concatenates an observable sequence of observable sequences.
   * @returns {Observable} An observable sequence that contains the elements of each observed inner sequence, in sequential order.
   */
  observableProto.concatAll = function () {
    return this.merge(1);
  };

  /** @deprecated Use `concatAll` instead. */
  observableProto.concatObservable = function () {
    //deprecate('concatObservable', 'concatAll');
    return this.merge(1);
  };
