
1.0.1 / 2016-10-13
==================

  * add MIT license file (fix #2)
  * isomorphic support (#3, @nescalante)
  * test: remove bad assert() call

1.0.0 / 2015-01-07
==================

  * Makefile: whitespace fix
  * enable Travis-CI testing
  * add .gitignore file
  * test: add test cases
  * initial commit
