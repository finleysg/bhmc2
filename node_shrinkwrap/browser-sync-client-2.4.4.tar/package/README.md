# browser-sync-client [![Build Status](https://travis-ci.org/BrowserSync/browser-sync-client.svg)](https://travis-ci.org/BrowserSync/browser-sync-client)

Client-side script for BrowserSync

## Contributors

```
   177	Shane Osbourne
     2	Sergey Slipchenko
     1	Hugo Dias
     1	Shinnosuke Watanabe
     1	Tim Schaub
     1	Shane Daniel
     1	Matthieu Vachon
```

## License
Copyright (c) 2014 Shane Osbourne
Licensed under the MIT license.
