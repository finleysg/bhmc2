# Installation
> `npm install --save @types/showdown`

# Summary
This package contains type definitions for Showdown 1.4.1 (https://github.com/coreyti/showdown).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/showdown

Additional Details
 * Last updated: Mon, 19 Sep 2016 17:28:59 GMT
 * File structure: UMD
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: Showdown, showdown

# Credits
These definitions were written by cbowdon <https://github.com/cbowdon>, Pei-Tang Huang <https://github.com/tan9/>.
